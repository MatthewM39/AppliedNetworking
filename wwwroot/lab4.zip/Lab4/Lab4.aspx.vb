﻿
Partial Class Lab4_Lab4
    Inherits System.Web.UI.Page

End Class
