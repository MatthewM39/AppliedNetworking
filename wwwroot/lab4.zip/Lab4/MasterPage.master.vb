﻿
Partial Class Lab4_MasterPage
    Inherits System.Web.UI.MasterPage
End Class

