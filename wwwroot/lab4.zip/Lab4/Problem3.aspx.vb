﻿
Partial Class Lab4_Problem3
    Inherits System.Web.UI.Page

End Class
