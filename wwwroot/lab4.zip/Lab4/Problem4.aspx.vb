﻿
Partial Class Lab4_Problem4
    Inherits System.Web.UI.Page

End Class
