﻿
Partial Class Lab3_s1
    Inherits System.Web.UI.Page

End Class
