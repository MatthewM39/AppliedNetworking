﻿
Partial Class Lab3_s5
    Inherits System.Web.UI.Page

End Class
