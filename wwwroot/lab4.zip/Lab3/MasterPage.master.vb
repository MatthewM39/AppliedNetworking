﻿
Partial Class Lab3_MasterPage
    Inherits System.Web.UI.MasterPage
End Class

