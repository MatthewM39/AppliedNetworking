﻿
Partial Class Lab3_s3
    Inherits System.Web.UI.Page

End Class
