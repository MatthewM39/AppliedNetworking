﻿
Partial Class Lab3_Problem2
    Inherits System.Web.UI.Page

End Class
