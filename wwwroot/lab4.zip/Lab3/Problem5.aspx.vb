﻿
Partial Class Lab3_Problem5
    Inherits System.Web.UI.Page

End Class
