﻿
Partial Class Lab3_Lab3
    Inherits System.Web.UI.Page

End Class
