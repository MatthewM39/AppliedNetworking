﻿
Partial Class Lab3_Problem1
    Inherits System.Web.UI.Page

End Class
