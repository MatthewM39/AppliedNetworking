﻿
Partial Class Lab3_s2
    Inherits System.Web.UI.Page

End Class
