﻿
Partial Class Lab3_Problem3
    Inherits System.Web.UI.Page

End Class
