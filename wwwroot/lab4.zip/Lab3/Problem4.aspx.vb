﻿
Partial Class Lab3_Problem4
    Inherits System.Web.UI.Page

End Class
