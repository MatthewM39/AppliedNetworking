﻿
Partial Class Lab3_s4
    Inherits System.Web.UI.Page

End Class
