﻿
Partial Class Gallery
    Inherits System.Web.UI.Page

End Class
