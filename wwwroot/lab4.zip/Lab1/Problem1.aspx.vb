﻿
Partial Class Lab1_Problem1
    Inherits System.Web.UI.Page

End Class
