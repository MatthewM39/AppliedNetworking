﻿
Partial Class Lab1_MasterPageLab1
    Inherits System.Web.UI.MasterPage
End Class

