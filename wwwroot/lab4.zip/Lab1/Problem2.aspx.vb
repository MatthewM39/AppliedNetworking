﻿
Partial Class Lab1_Problem2
    Inherits System.Web.UI.Page

End Class
