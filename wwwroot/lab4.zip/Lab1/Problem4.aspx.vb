﻿
Partial Class Lab1_Problem4
    Inherits System.Web.UI.Page

End Class
