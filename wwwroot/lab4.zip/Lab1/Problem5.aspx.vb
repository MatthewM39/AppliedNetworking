﻿
Partial Class Lab1_Problem5
    Inherits System.Web.UI.Page

End Class
