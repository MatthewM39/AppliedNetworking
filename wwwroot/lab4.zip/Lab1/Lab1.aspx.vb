﻿
Partial Class Lab1_Lab1
    Inherits System.Web.UI.Page

End Class
