﻿
Partial Class Lab1_Problem6
    Inherits System.Web.UI.Page

End Class
