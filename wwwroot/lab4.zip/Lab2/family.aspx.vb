﻿
Partial Class Lab2_familly
    Inherits System.Web.UI.Page

End Class
