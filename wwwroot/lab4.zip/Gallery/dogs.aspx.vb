﻿
Partial Class Gallery_dogs
    Inherits System.Web.UI.Page

End Class
