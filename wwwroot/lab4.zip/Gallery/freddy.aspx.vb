﻿
Partial Class Gallery_freddy
    Inherits System.Web.UI.Page

End Class
