﻿
Partial Class Gallery_me_and_besty
    Inherits System.Web.UI.Page

End Class
