﻿
Partial Class Gallery_zoey
    Inherits System.Web.UI.Page

End Class
