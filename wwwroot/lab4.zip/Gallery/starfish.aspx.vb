﻿
Partial Class Gallery_starfish
    Inherits System.Web.UI.Page

End Class
