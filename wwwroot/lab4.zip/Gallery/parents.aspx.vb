﻿
Partial Class Gallery_parents
    Inherits System.Web.UI.Page

End Class
